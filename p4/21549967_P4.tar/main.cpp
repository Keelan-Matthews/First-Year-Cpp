#include "tome.h"
#include <cstring>
#include <string>
#include <iostream>

using namespace std;

int main()
{
	string list[] = {"Potion 1", "Potion 2", "Potion 3"};

	return 0;
}