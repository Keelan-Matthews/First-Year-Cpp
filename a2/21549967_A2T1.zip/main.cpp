#include <iostream>
#include "piece.h"
using namespace std;
int main()
{
    piece firstPiece("rook",'b',7,0);
    piece plusPiece(firstPiece);
    piece piece2 = plusPiece + "5,7";
    cout << piece2 << endl;
    return 0;
}
