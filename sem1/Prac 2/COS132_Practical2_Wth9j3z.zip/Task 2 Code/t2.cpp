#include <iostream>
using namespace std;
int main() {
	////declare your float variable here.
	

	///User Input
	cout<<"Enter a float number:";
	cin>>myPi;

	//declare your pointer here

	
	return 0;
}
