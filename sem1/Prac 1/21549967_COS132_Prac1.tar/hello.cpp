#include <iostream>

int main() {
	std::cout<<"Hello, world! I am u21549967"<<std::endl;
	return 0;
}
